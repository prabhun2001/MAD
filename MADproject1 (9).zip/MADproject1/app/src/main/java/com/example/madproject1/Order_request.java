package com.example.madproject1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Order_request extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_order_request);
    }
}