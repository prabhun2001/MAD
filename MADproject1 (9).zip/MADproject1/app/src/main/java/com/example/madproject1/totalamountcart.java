package com.example.madproject1;

public class totalamountcart {
    public static int total;

    public totalamountcart() {

    }

    public static int getTotal() {
        return total;
    }

    public static void setTotal(int total) {
        totalamountcart.total = total;
    }
}
