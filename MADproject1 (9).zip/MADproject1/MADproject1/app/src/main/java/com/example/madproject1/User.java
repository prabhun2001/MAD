package com.example.madproject1;

public class User {
    public String name,phone,email;

    public User(){

    }

    public User(String name,String phone,String email){
        this.name = name;
        this.phone = phone;
        this.email = email;
    }
}
