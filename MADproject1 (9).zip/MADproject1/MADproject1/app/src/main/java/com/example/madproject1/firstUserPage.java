package com.example.madproject1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class firstUserPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_first_user_page);
    }
}